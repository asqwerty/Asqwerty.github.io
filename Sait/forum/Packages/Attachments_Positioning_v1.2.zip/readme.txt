[hr]
[center][color=red][size=16pt][b]ATTACHMENTS POSITIONING v1.2[/b][/size][/color]
[url=http://custom.simplemachines.org/mods/index.php?action=search;author=3847][b]By Quake101[/b][/url]
[/center]
[hr]
[center][url=http://custom.simplemachines.org/mods/index.php?mod=1159][b]Link to Mod[/b][/url] | [url=http://www.simplemachines.org/community/index.php?topic=233640.0][b]Comment On This Mod[/b][/url] | [url=http://www.badassmustangs.com/forums/paypal.html][b]Donate[/b][/url][/center]

[color=blue][b][size=12pt][u]Introduction[/u][/size][/b][/color]
The mod adds the ability to position your attachments in your post using [attachment=1] bbcode
Where 1 is the first attachment in that post.
It is ONLY possible to position attachments which are tied to that POST only.

[color=blue][b][size=12pt][u]Features[/u][/size][/b][/color]
o Adds [attachment=n] bbcode to position attachments within the post (where n is the number of the attachment in the post, eg first = 1, second = 2)
o Adds [Insert Attachment 1] next to each attachment/upload box to insert the bbcode.
o The default listing of attachments at the bottom of the post is unaffected.
o Text string is shown as alternative when quoted or in code
o Error Text string shown for invalid/missing/deleted attachments
o Reloads the attachments for Ajax Editing
o Text string shown in place of attachment for Recent posts/Previewing and Topic&Reply History

There are no admin settings with this mod.  To disable the mod you must uninstall it.

[color=blue][b][size=12pt][u]Installation[/u][/size][/b][/color]
Simply install the package to install this modification on the SMF Default Core theme.
Manual edits will be required for other themes.

This mod is compatible with SMF 1.1.x and SMF 2.0 Beta 3 Public only.

[color=blue][b][size=12pt][u]Donate[/u][/size][/b][/color]
Has this modification helped you? Support the developer by [url=http://www.badassmustangs.com/forums/paypal.html][color=red][b]Donating[/b][/color][/url]

[color=blue][b][size=12pt][u]Support[/u][/b][/color]
Please use the modification thread for support with this modification.

[color=blue][b][size=12pt][u]Changelog[/u][/size][/b][/color]
[b]0.5 BETA - 27th October 2007[/b]
o Initial release per request
[b]1.0 - 30th October 2007[/b]
o First PUBLIC release
[b]1.1 - 1st December 2007[/b]
o Fixed [Insert] link number
[b]1.2 - 13 April 2008[/b]
o Fixed displaying of image attachments twice that use [attachment=n] bbcode
o Made 2.0 Beta 3 Public compatible
o Added Portuguese & Brazilian language support (Thanks joomlamz)