<?php
// Version: 2.0; Modifications

 
// * Watermark mod by Digger
$txt['watermark'] = 'Watermark';
$txt['watermarkEnabled'] = 'Abilita watermark (for JPG, GIF, PNG)';
$txt['watermarkImage'] = 'Nome del file del watermark. Formati supportati GIF e PNG.<br />Carica il tuo file nella directory /Watermark/Logo.';
$txt['watermarkTransparency'] = 'Opacità watermark (0-100). Solo per watermark GIF.';
$txt['watermarkJpegQuality'] = 'Qualità Jpeg (0-100). Gamma da 0 (qualità peggiore, file leggero) a 100 (migliore qualità, file pesante).';
$txt['watermarkPngCompression'] = 'Comprssione Png(0-9)';
$txt['watermarkMaxHeight'] = 'Watermark per immagini di altezza superiore a (pixels)';
$txt['watermarkMaxWidth'] = 'Watermark per immagini di larghezza superiore a (pixels)';
$txt['watermarkBorder'] = 'Spazio tra il watermark e il bordo più vicino (pixels)';
$txt['watermarkPosition'] = 'Posizione watermark';
$txt['watermarkPositionTopLeft'] = 'Angolo superiore sinistro';
$txt['watermarkPositionTopRight'] = 'Angolo superiore destro';
$txt['watermarkPositionBottomLeft'] = 'Angolo inferiore sinistro';
$txt['watermarkPositionBottomRight'] = 'Angolo inferiore destro';
$txt['watermarkPositionCenter'] = 'Centrale';
$txt['watermarkLogoTitle'] = 'Watermark';
$txt['watermarkTestTitle'] = 'Esempio JPG';
$txt['watermarkTestOriginal'] = 'Dimensione originale: ';
$txt['watermarkTestWatermarked'] = 'Dimensione filigranata: ';
$txt['watermarkTestText'] = 'Se l'immagine dimostrativa non è aggiornata dopo il cambio d'impostazioni, aggiorna la pagina nel tuo browser.';
// Watermark Mod *

?>