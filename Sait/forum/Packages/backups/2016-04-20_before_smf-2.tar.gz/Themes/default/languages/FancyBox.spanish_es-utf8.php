<?php

$txt['fancybox_settings'] = 'FancyBox 4 SMF';
$txt['fancybox_desc'] = 'Esta modificación añade un efecto FancyBox a las imágenes en línea y adjuntas.';
$txt['fancybox_open_effect'] = 'Efecto al abrir la imagen';
$txt['fancybox_open_set_unu'] = 'Zoom in elástico';
$txt['fancybox_open_set_du'] = 'Aspecto de desvanecimiento';
$txt['fancybox_open_speed'] = 'Velocidad de la animación al abrir, en milésimas de segundo';
$txt['fancybox_close_effect'] = 'Efecto al cerrar la imagen';
$txt['fancybox_close_set_unu'] = 'Zoom out elástico';
$txt['fancybox_close_set_du'] = 'Desaparición del desvanecimiento';
$txt['fancybox_close_speed'] = 'Velocidad de la animación al cerrar, en milésimas de segundo';
$txt['fancybox_next_effect'] = 'Efecto al cambiar a próxima imagen';
$txt['fancybox_next_speed'] = 'Velocidad de la animación al cambiar a próxima imagen, en milésimas de segundo';
$txt['fancybox_prev_effect'] = 'Efecto al cambiar a imagen anterior';
$txt['fancybox_prev_speed'] = 'Velocidad de la animación al cambiar a imagen anterior, en milésimas de segundo';
$txt['fancybox_effect_unu'] = 'Rebobinado elástico';
$txt['fancybox_effect_du'] = 'Transición lisa';
$txt['fancybox_title_position'] = 'Posición del título';
$txt['fancybox_title_set_unu'] = 'Flotar';
$txt['fancybox_title_set_du'] = 'Dentro de diapositivas';
$txt['fancybox_title_set_tri'] = 'Fuera de diapositivas';
$txt['fancybox_title_set_kvar'] = 'Sobre diapositivas';
$txt['fancybox_panel_position'] = 'Posición del panel de control';
$txt['fancybox_panel_set_unu'] = 'Arriba';
$txt['fancybox_panel_set_du'] = 'Abajo';
$txt['fancybox_autoplay'] = 'Autoplay cuando cualquier imagen se está abriendo';
$txt['fancybox_playspeed'] = 'Retraso entre las diapositivas, en milésimas de segundo';
$txt['fancybox_thumbnails'] = 'Miniaturas de pantalla bajo las diapositivas';
$txt['fancybox_traffic'] = 'Ahorro de tráfico <div class="smalltext">Si está activado, los mensajes en lugar de las imágenes originales será una pequeña imagen especial. Cuando se hace clic en él, verá la imagen original.</div>';

$txt['fancy_click'] = 'Click para cargar la imagen original';
$txt['fancy_text_error'] = 'El contenido solicitado no se puede cargar.<br/>Inténtalo de nuevo más tarde.';
$txt['fancy_button_next'] = 'Siguiente';
$txt['fancy_button_prev'] = 'Anterior';
$txt['fancy_slideshow_start'] = 'Iniciar presentación';
$txt['fancy_slideshow_pause'] = 'Pausar presentación';
$txt['fancy_toggle_size'] = 'Cambiar el tamaño';

?>