<?php

$txt['quick_spoiler'] = 'Spoiler';
$txt['qs_title'] = 'T&iacutetulo Spoiler Padr&atilde;o';
$txt['qs_settings'] = 'Configura&ccedil;&otilde;es de spoiler [Spoiler r&aacute;pida]';
$txt['qs_no_spoiler_sorry'] = 'Desculpe, mas voc&ecirc; n&atilde;o tem permiss&atilde;o para visualizar o conte&uacute;do Spoiler.';
$txt['groups_view_spoiler'] = 'Visualizando o conte&uacute;do Spoiler';

$txt['permissionname_view_spoiler'] = $txt['groups_view_spoiler'];
$txt['permissionhelp_view_spoiler'] = 'Os usu&aacute;rios podem visualizar informa&ccedil;&otilde;es que escondido sob spoilers.';

?>