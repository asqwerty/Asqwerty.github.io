<?php
// Version: 2.0; Modifications

 
// * Watermark mod by Digger
$txt['watermark'] = 'Wasserzeichen';
$txt['watermarkEnabled'] = 'Wasserzeichen einschalten (fur JPG, GIF, PNG)';
$txt['watermarkImage'] = 'Wasserzeichen Dateiname. Unterstutzt werden die Formate GIF und PNG.<br />Upload dein Wasserzeichen nach /Watermark/Logo/.';
$txt['watermarkTransparency'] = 'Wasserzeichen Transparenz  (0-100). Nur fur GIF Wasserzeichen.';
$txt['watermarkJpegQuality'] = 'Jpeg Qualitat (0-100). Einstellung von 0 (schlechteste, kleine Files) bis 100 (beste Qualitat, gro?ere Files).';
$txt['watermarkPngCompression'] = 'Png Kompression (0-9)';
$txt['watermarkMaxHeight'] = 'Kennzeichne Bilder mit einer Hohe ab (pixels)';
$txt['watermarkMaxWidth'] = 'Kennzeichne Bilder mit einer Breite ab (pixels)';
$txt['watermarkBorder'] = 'Abstand des Wasserzeichens vom Rand (pixels)';
$txt['watermarkPosition'] = 'Wasserzeichen Position';
$txt['watermarkPositionTopLeft'] = 'Oben Links ';
$txt['watermarkPositionTopRight'] = 'Oben Rechts ';
$txt['watermarkPositionBottomLeft'] = 'Unten Links ';
$txt['watermarkPositionBottomRight'] = 'Unten Rechts ';
$txt['watermarkPositionCenter'] = 'Zentrieren';
$txt['watermarkLogoTitle'] = 'Wasserzeichen';
$txt['watermarkTestTitle'] = 'JPG Beispiel';
$txt['watermarkTestOriginal'] = 'Original gro?e: ';
$txt['watermarkTestWatermarked'] = 'Wasserzeichen Gro?e: ';
$txt['watermarkTestText'] = 'Erneuert sich die Demo nicht wenn du die Einstellungen veranderst, dann Refresh deinen Browser.';
// Watermark Mod *

?>