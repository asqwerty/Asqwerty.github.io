<?php
// Version: 2.1 Beta 1; Modifications

 
// * Watermark mod by Digger
$txt['watermark'] = 'Водяной знак';
$txt['watermarkEnabled'] = 'Включить водяной знак. Логотип будет накладываться на файлы формата JPG, GIF, PNG. ';
$txt['watermarkUserEnabled'] = 'Разрешить пользователям при загрузке изображений выбирать, накладывать водяной знак или нет (форма создания сообщения - дополнительные опции - наложить водяной знак).  ';
$txt['watermarkUserCheck'] = 'По умолчанию выбрано';
$txt['watermarkUserChecked'] = 'Накладывать';
$txt['watermarkUserUnchecked'] = 'Не накладывать';
$txt['watermarkImage'] = 'Имя файла с логотипом водяного знака. Поддерживаются форматы GIF и PNG.<br />Файлы с логотипами находятся в каталоге /Watermark/Logo<br />В каталоге /Watermark находится демо-файл watermark_demo.jpg, который вы можете заменить на свой с таким же именем.';
$txt['watermarkTransparency'] = 'Непрозрачность водяного знака формата GIF при наложении (0-100).';
$txt['watermarkJpegQuality'] = 'Качество Jpeg (0-100). Чем больше, тем лучше качество, но больше размер JPG файла после наложения водяного знака. Оптимально 75 - 85.'; 
$txt['watermarkPngCompression'] = 'Сжатие Png (0-9). Чем меньше, тем лучше качество, но больше размер PNG файла после наложения водяного знака. Оптимально 5 - 6';
$txt['watermarkMaxHeight'] = 'Обрабатывать изображения у которых Высота в пикселах больше';
$txt['watermarkMaxWidth'] = 'Обрабатывать изображения у которых Ширина в пикселах больше';
$txt['watermarkBorder'] = 'Расстояние от водяного знака до границ изображения, в пикселах';
$txt['watermarkPosition'] = 'Расположение логотипа на изображении';
$txt['watermarkPositionTopLeft'] = 'Левый верхний угол';
$txt['watermarkPositionTopRight'] = 'Правый верхний угол';
$txt['watermarkPositionBottomLeft'] = 'Левый нижний угол';
$txt['watermarkPositionBottomRight'] = 'Правый нижний угол';
$txt['watermarkPositionCenter'] = 'По центру';
$txt['watermarkLogoTitle'] = 'Логотип';
$txt['watermarkTestTitle'] = 'Образец JPG';
$txt['watermarkTestOriginal'] = 'Исходный размер: ';
$txt['watermarkTestWatermarked'] = 'Размер с логотипом: ';
$txt['watermarkTestText'] = 'Если картинка не обновилась после изменения настроек, обновите страницу в своем браузере.';
$txt['watermarkBackupEnabled'] = 'Сохранять копии оригинальных файлов при наложении водяных знаков. Копии будут сохранятся в файлы вида имя_файла_orig.';
$txt['maintain_watermark'] = 'Промаркировать водяным знаком все непомеченные вложения.';
$txt['maintain_watermark_restore'] = 'Восстановить исходное состояние всех помеченных вложений (если была включена опция сохранения копий оригиналов).';
$txt['watermarkUserCheckbox'] = 'Наложить водяной знак на вложенные изображения.';
$txt['spoiler'] = "Занавеска";
$txt['debug_hide'] = 'Задёрнуть';
$txt['debug_show'] = 'Одёрнуть';
$txt['spoiler_no_guests'] = 'Активируёте, чтоб скрыть занавеску от любопытных гостей:';
$txt['spoiler_no_guest_html'] = 'Вы должны зарегистрироваться чтоб заглянуть за занавеску!';
$txt['Klet'] = 'Клеть';
$txt['Stepen'] = 'Степень';
// Watermark Mod *
 
// * Watermark mod by Digger
$txt['watermark'] = 'Водяной знак';
$txt['watermarkEnabled'] = 'Включить водяной знак. Логотип будет накладываться на файлы формата JPG, GIF, PNG. ';
$txt['watermarkUserEnabled'] = 'Разрешить пользователям при загрузке изображений выбирать, накладывать водяной знак или нет (форма создания сообщения - дополнительные опции - наложить водяной знак).  ';
$txt['watermarkUserCheck'] = 'По умолчанию выбрано';
$txt['watermarkUserChecked'] = 'Накладывать';
$txt['watermarkUserUnchecked'] = 'Не накладывать';
$txt['watermarkImage'] = 'Имя файла с логотипом водяного знака. Поддерживаются форматы GIF и PNG.<br />Файлы с логотипами находятся в каталоге /Watermark/Logo<br />В каталоге /Watermark находится демо-файл watermark_demo.jpg, который вы можете заменить на свой с таким же именем.';
$txt['watermarkTransparency'] = 'Непрозрачность водяного знака формата GIF при наложении (0-100).';
$txt['watermarkJpegQuality'] = 'Качество Jpeg (0-100). Чем больше, тем лучше качество, но больше размер JPG файла после наложения водяного знака. Оптимально 75 - 85.'; 
$txt['watermarkPngCompression'] = 'Сжатие Png (0-9). Чем меньше, тем лучше качество, но больше размер PNG файла после наложения водяного знака. Оптимально 5 - 6';
$txt['watermarkMaxHeight'] = 'Обрабатывать изображения у которых Высота в пикселах больше';
$txt['watermarkMaxWidth'] = 'Обрабатывать изображения у которых Ширина в пикселах больше';
$txt['watermarkBorder'] = 'Расстояние от водяного знака до границ изображения, в пикселах';
$txt['watermarkPosition'] = 'Расположение логотипа на изображении';
$txt['watermarkPositionTopLeft'] = 'Левый верхний угол';
$txt['watermarkPositionTopRight'] = 'Правый верхний угол';
$txt['watermarkPositionBottomLeft'] = 'Левый нижний угол';
$txt['watermarkPositionBottomRight'] = 'Правый нижний угол';
$txt['watermarkPositionCenter'] = 'По центру';
$txt['watermarkLogoTitle'] = 'Логотип';
$txt['watermarkTestTitle'] = 'Образец JPG';
$txt['watermarkTestOriginal'] = 'Исходный размер: ';
$txt['watermarkTestWatermarked'] = 'Размер с логотипом: ';
$txt['watermarkTestText'] = 'Если картинка не обновилась после изменения настроек, обновите страницу в своем браузере.';
$txt['watermarkBackupEnabled'] = 'Сохранять копии оригинальных файлов при наложении водяных знаков. Копии будут сохранятся в файлы вида имя_файла_orig.';
$txt['maintain_watermark'] = 'Промаркировать водяным знаком все непомеченные вложения.';
$txt['maintain_watermark_restore'] = 'Восстановить исходное состояние всех помеченных вложений (если была включена опция сохранения копий оригиналов).';
$txt['watermarkUserCheckbox'] = 'Наложить водяной знак на вложенные изображения.';
// Watermark Mod *

?>