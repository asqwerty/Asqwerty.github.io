<?php

$txt['quick_spoiler'] = 'Spoiler';
$txt['qs_title'] = 'Titolo spoiler di default';
$txt['qs_settings'] = 'Impostazioni Spoiler [Spoiler Rapido]';
$txt['qs_no_spoiler_sorry'] = 'Spiacente, ma non sei autorizzato a visualizzare il contenuto degli spoiler.';
$txt['groups_view_spoiler'] = 'Visualizzare il contenuto degli spoiler';

$txt['permissionname_view_spoiler'] = $txt['groups_view_spoiler'];
$txt['permissionhelp_view_spoiler'] = 'Gli utenti possono vedere il contenuto nascosto negli spoiler.';

?>