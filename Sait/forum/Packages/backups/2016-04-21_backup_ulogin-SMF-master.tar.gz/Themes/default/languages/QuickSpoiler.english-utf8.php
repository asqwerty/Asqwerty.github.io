<?php

$txt['quick_spoiler'] = 'Spoiler';
$txt['qs_title'] = 'Default spoiler title';
$txt['qs_settings'] = 'Spoiler Settings [Quick Spoiler]';
$txt['qs_no_spoiler_sorry'] = 'Sorry but you are not allowed to view spoiler contents.';
$txt['groups_view_spoiler'] = 'Viewing spoiler contents';

$txt['permissionname_view_spoiler'] = $txt['groups_view_spoiler'];
$txt['permissionhelp_view_spoiler'] = 'Users can view info that hidden under spoilers.';

?>