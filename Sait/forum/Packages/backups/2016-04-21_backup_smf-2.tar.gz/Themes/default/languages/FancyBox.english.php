<?php

$txt['fancybox_settings'] = 'FancyBox 4 SMF';
$txt['fancybox_desc'] = 'This modification adds nice fancybox effect to in-line and attached images.';
$txt['fancybox_open_effect'] = 'Effect when opening image';
$txt['fancybox_open_set_unu'] = 'Elastic zoom in';
$txt['fancybox_open_set_du'] = 'Fade appearance';
$txt['fancybox_open_speed'] = 'Animation speed when opening, in milliseconds';
$txt['fancybox_close_effect'] = 'Effect when closing image';
$txt['fancybox_close_set_unu'] = 'Elastic zoom out';
$txt['fancybox_close_set_du'] = 'Fade disappearance';
$txt['fancybox_close_speed'] = 'Animation speed when closing, in milliseconds';
$txt['fancybox_next_effect'] = 'Effect when changing next image';
$txt['fancybox_next_speed'] = 'Animation speed when chaning next image, in milliseconds';
$txt['fancybox_prev_effect'] = 'Effect when changing prev image';
$txt['fancybox_prev_speed'] = 'Animation speed when chaning prev image, in milliseconds';
$txt['fancybox_effect_unu'] = 'Elastic rewinding';
$txt['fancybox_effect_du'] = 'Smooth transition';
$txt['fancybox_title_position'] = 'Title position';
$txt['fancybox_title_set_unu'] = 'Float';
$txt['fancybox_title_set_du'] = 'Inside slide';
$txt['fancybox_title_set_tri'] = 'Outside slide';
$txt['fancybox_title_set_kvar'] = 'Over slide';
$txt['fancybox_panel_position'] = 'Control panel position';
$txt['fancybox_panel_set_unu'] = 'Top';
$txt['fancybox_panel_set_du'] = 'Bottom';
$txt['fancybox_autoplay'] = 'Autoplay when any image is opening';
$txt['fancybox_playspeed'] = 'Delay between slides, in milliseconds';
$txt['fancybox_thumbnails'] = 'Display thumbnails below slides';
$txt['fancybox_prepare'] = 'Processing of images that inserted with <strong>img</strong> tag';
$txt['fancybox_traffic'] = 'Traffic saving <div class="smalltext">If enabled, unregistered users will see a special small image with running little man instead of original images. When clicked on it, they will see an original image.</div>';

$txt['fancy_click'] = 'Click to load original image';
$txt['fancy_text_error'] = 'The requested content cannot be loaded.<br/>Please try again later.';
$txt['fancy_button_next'] = 'Next';
$txt['fancy_button_prev'] = 'Previous';
$txt['fancy_slideshow_start'] = 'Start slideshow';
$txt['fancy_slideshow_pause'] = 'Pause slideshow';
$txt['fancy_toggle_size'] = 'Toggle size';

?>