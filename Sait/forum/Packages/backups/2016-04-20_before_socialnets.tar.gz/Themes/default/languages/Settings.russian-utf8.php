<?php
// Version: 2.1 Beta 2; Settings

global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'Тема оформления по умолчанию от Simple Machines.<br><br>Авторы: команда Simple Machines';

?>