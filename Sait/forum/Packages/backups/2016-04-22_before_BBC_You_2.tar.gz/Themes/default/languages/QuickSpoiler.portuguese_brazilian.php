<?php

$txt['quick_spoiler'] = 'Spoiler';
$txt['qs_title'] = 'T�tulo Spoiler Padr�o';
$txt['qs_settings'] = 'Configura��es de spoiler [Spoiler r�pida]';
$txt['qs_no_spoiler_sorry'] = 'Desculpe, mas voc� n�o tem permiss�o para visualizar o conte�do Spoiler.';
$txt['groups_view_spoiler'] = 'Visualizando o conte�do Spoiler';

$txt['permissionname_view_spoiler'] = $txt['groups_view_spoiler'];
$txt['permissionhelp_view_spoiler'] = 'Os usu�rios podem visualizar informa��es que escondido sob spoilers.';

?>