<?php

$txt['fancybox_settings'] = 'FancyBox 4 SMF';
$txt['fancybox_desc'] = 'Эта модификация добавляет красивые эффекты при просмотре изображений в сообщениях и вложениях.';
$txt['fancybox_open_effect'] = 'Эффект при открытии изображений';
$txt['fancybox_open_set_unu'] = 'Эластичное увеличение';
$txt['fancybox_open_set_du'] = 'Плавное появление';
$txt['fancybox_open_speed'] = 'Скорость анимации при открытии, в миллисекундах';
$txt['fancybox_close_effect'] = 'Эффект при закрытии изображений';
$txt['fancybox_close_set_unu'] = 'Эластичное уменьшение';
$txt['fancybox_close_set_du'] = 'Плавное исчезновение';
$txt['fancybox_close_speed'] = 'Скорость анимации при закрытии, в миллисекундах';
$txt['fancybox_next_effect'] = 'Эффект при переходе к следующему изображению';
$txt['fancybox_next_speed'] = 'Скорость анимации при переходе, в миллисекундах';
$txt['fancybox_prev_effect'] = 'Эффект при возвращении к предыдущему изображению';
$txt['fancybox_prev_speed'] = 'Скорость анимации при возвращении, в миллисекундах';
$txt['fancybox_effect_unu'] = 'Перемотка';
$txt['fancybox_effect_du'] = 'Плавный переход';
$txt['fancybox_title_position'] = 'Расположение заголовка';
$txt['fancybox_title_set_unu'] = 'Плавающий';
$txt['fancybox_title_set_du'] = 'Внутри слайда';
$txt['fancybox_title_set_tri'] = 'Снаружи слайда';
$txt['fancybox_title_set_kvar'] = 'Поверх слайда';
$txt['fancybox_panel_position'] = 'Расположение элементов управления во время слайд-шоу';
$txt['fancybox_panel_set_unu'] = 'Сверху';
$txt['fancybox_panel_set_du'] = 'Снизу';
$txt['fancybox_autoplay'] = 'Автозапуск слайд-шоу (если изображений несколько)';
$txt['fancybox_playspeed'] = 'Задержка перехода между слайдами, в миллисекундах';
$txt['fancybox_thumbnails'] = 'Отображать миниатюры при просмотре слайдов';
$txt['fancybox_prepare'] = 'Обработка изображений, вставленных с помощью тега <strong>img</strong>';
$txt['fancybox_traffic'] = 'Экономия трафика <div class="smalltext">Если включено, незарегистрированные пользователи будут видеть маленькую картинку с бегущим человечком, вместо оригинальных изображений. При клике на эту картинку будет загружаться оригинал.</div>';

$txt['fancy_click'] = 'Нажми для загрузки оригинального изображения';
$txt['fancy_text_error'] = 'Запрашиваемое изображение не может быть загружено.<br/>Попробуйте позже.';
$txt['fancy_button_next'] = 'Следующее';
$txt['fancy_button_prev'] = 'Предыдущее';
$txt['fancy_slideshow_start'] = 'Слайдшоу';
$txt['fancy_slideshow_pause'] = 'Пауза';
$txt['fancy_toggle_size'] = 'Переключить размер';

?>