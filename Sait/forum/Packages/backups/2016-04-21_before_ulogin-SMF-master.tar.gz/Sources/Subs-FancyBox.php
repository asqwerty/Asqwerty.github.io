<?php
/**
* FancyBox 4 SMF � 2012-2015, Bugo
* Subs-FancyBox.php
* License http://creativecommons.org/licenses/by-nc/3.0/deed.ru CC BY-NC
* Support and updates for this software can be found at	http://dragomano.ru
*/

if (!defined('SMF'))
	die('Hacking attempt...');
	
function fancybox_load_theme()
{
	global $context, $settings, $txt, $modSettings;
	
	loadLanguage('FancyBox');
	
	if (in_array($context['current_action'], array('admin', 'helpadmin', 'printpage')) || WIRELESS)
		return;
	
	$context['html_headers'] .= '
	<link rel="stylesheet" type="text/css" href="' . $settings['default_theme_url'] . '/scripts/fancybox/jquery.fancybox.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="' . $settings['default_theme_url'] . '/scripts/fancybox/helpers/jquery.fancybox-buttons.css" media="screen" />';
	
	if (!empty($modSettings['fancybox_thumbnails']))
		$context['html_headers'] .= '
	<link rel="stylesheet" type="text/css" href="' . $settings['default_theme_url'] . '/scripts/fancybox/helpers/jquery.fancybox-thumbs.css" media="screen" />';
	
	$cdn = $txt['lang_dictionary'] == 'ru' ? 'http://yandex.st/jquery/1.11.2/jquery.min.js' : 'http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js';

	$context['insert_after_template'] .= '
	<script type="text/javascript">window.jQuery || document.write(unescape(\'%3Cscript src="' . $cdn . '"%3E%3C/script%3E\'))</script>
	<script type="text/javascript" src="https://code.jquery.com/jquery-migrate-1.2.1.js"></script>
	<script type="text/javascript" src="' . $settings['default_theme_url'] . '/scripts/fancybox/jquery.mousewheel-3.0.6.pack.js"></script>
	<script type="text/javascript" src="' . $settings['default_theme_url'] . '/scripts/fancybox/jquery.fancybox.pack.js"></script>
	<script type="text/javascript" src="' . $settings['default_theme_url'] . '/scripts/fancybox/helpers/jquery.fancybox-buttons.js"></script>';
	
	if (!empty($modSettings['fancybox_thumbnails']))
		$context['insert_after_template'] .= '
	<script type="text/javascript" src="' . $settings['default_theme_url'] . '/scripts/fancybox/helpers/jquery.fancybox-thumbs.js"></script>';
	
	$context['insert_after_template'] .= '
	<script type="text/javascript"><!-- // --><![CDATA[
		jQuery(document).ready(function($){
			$("a[id^=link_]").addClass("fancybox").removeAttr("onclick").attr("rel", "group");
			$("div[id*=_footer]").each(function(){
				var id = $(this).attr("id");
				$("#" + id + " a[rel=group]").attr("rel", "group_" + id);
			});
			$(".fancybox").fancybox({
				type: "image",
				openEffect: "' . $modSettings['fancybox_open_effect'] . '",
				openSpeed: ' . (int) $modSettings['fancybox_open_speed'] . ',
				closeEffect: "' . $modSettings['fancybox_close_effect'] . '",
				closeSpeed: ' . (int) $modSettings['fancybox_close_speed'] . ',
				nextEffect: "' . $modSettings['fancybox_next_effect'] . '",
				nextSpeed: ' . (int) $modSettings['fancybox_next_speed'] . ',
				prevEffect: "' . $modSettings['fancybox_prev_effect'] . '",
				prevSpeed: ' . (int) $modSettings['fancybox_prev_speed'] . ',
				autoPlay: ' . (!empty($modSettings['fancybox_autoplay']) ? 'true' : 'false') . ',
				playSpeed: ' . (int) $modSettings['fancybox_playspeed'] . ',
				tpl: {
					error: \'<p class="fancybox-error">' . $txt['fancy_text_error'] . '</p>\',
					closeBtn: \'<div title="' . $txt['find_close'] . '" class="fancybox-item fancybox-close"></div>\',
					next: \'<a title="' . $txt['fancy_button_next'] . '" class="fancybox-item fancybox-next"><span></span></a>\',
					prev: \'<a title="' . $txt['fancy_button_prev'] . '" class="fancybox-item fancybox-prev"><span></span></a>\'
				},
				helpers: {
					title: {type: "' . $modSettings['fancybox_title_position'] . '"},
					buttons: {
						tpl: \'<div id="fancybox-buttons"><ul><li><a class="btnPrev" title="' . $txt['fancy_button_prev'] . '" href="javascript:;"></a></li><li><a class="btnPlay" title="' . $txt['fancy_slideshow_start'] . '" href="javascript:;"></a></li><li><a class="btnNext" title="' . $txt['fancy_button_next'] . '" href="javascript:;"></a></li><li><a class="btnToggle" title="' . $txt['fancy_toggle_size'] . '" href="javascript:;"></a></li><li><a class="btnClose" title="' . $txt['find_close'] . '" href="javascript:jQuery.fancybox.close();"></a></li></ul></div>\',
						position : "' . $modSettings['fancybox_panel_position'] . '"
					},';
		
	if (!empty($modSettings['fancybox_thumbnails']))
		$context['insert_after_template'] .= '
					thumbs: {
						width: 50,
						height: 50
					}';
					
	$context['insert_after_template'] .= '
				}
			});
		});
	// ]]></script>';
}

function fancybox_bbc_codes(&$codes)
{
	global $modSettings, $user_info, $settings, $txt;

	if (empty($_REQUEST['topic']) || WIRELESS || empty($modSettings['enableBBC']) || empty($modSettings['fancybox_prepare']))
		return;
	
	$disabled = array();
	if (!empty($modSettings['disabledBBC']))
		foreach (explode(",", $modSettings['disabledBBC']) as $tag)
			$disabled[$tag] = true;
	
	if (isset($disabled['img']))
		return;

	foreach ($codes as &$code) {
		if ($code['tag'] == 'img') {
			if ($user_info['is_guest'])
				$hiwi = '';
			else
				$hiwi = '{width}{height}';
			
			if ($code['content'] == '<img src="$1" alt="" class="bbc_img" />')
				$code['content'] = '<a href="$1" class="fancybox" rel="topic"><img src="' . (!empty($modSettings['fancybox_traffic']) && $user_info['is_guest'] ? $settings['default_images_url'] . '/traffic.gif" title="' . $txt['fancy_click'] : '$1') . '" alt="" class="bbc_img" /></a>';
			
			if ($code['content'] == '<img src="$1" alt="{alt}"{width}{height} class="bbc_img resized" />')
				$code['content'] = '<a href="$1" class="fancybox" title="{alt}" rel="topic"><img src="' . (!empty($modSettings['fancybox_traffic']) && $user_info['is_guest'] ? $settings['default_images_url'] . '/traffic.gif" title="' . $txt['fancy_click'] : '$1') . '" alt="{alt}"' . $hiwi . ' /></a>';
		}
	}
}

function fancybox_admin_areas(&$admin_areas)
{
	global $txt;
	
	$admin_areas['config']['areas']['modsettings']['subsections']['fancybox'] = array($txt['fancybox_settings']);
}

function fancybox_modifications(&$subActions)
{
	$subActions['fancybox'] = 'fancybox_settings';
}

function fancybox_settings()
{
	global $txt, $context, $scripturl, $modSettings;
	
	$context['page_title'] = $context['settings_title'] = $txt['fancybox_settings'];
	$context['post_url'] = $scripturl . '?action=admin;area=modsettings;save;sa=fancybox';
	$context[$context['admin_menu_name']]['tab_data']['tabs']['fancybox'] = array('description' => $txt['fancybox_desc']);
	
	if (!empty($modSettings['fancybox_thumbnails']))
		updateSettings(array('fancybox_panel_position' => 'top'));
	
	$config_vars = array(
		array('select', 'fancybox_open_effect', array('elastic' => $txt['fancybox_open_set_unu'], 'fade' => $txt['fancybox_open_set_du'], 'none' => $txt['no'])),
		array('int', 'fancybox_open_speed'),
		array('select', 'fancybox_close_effect', array('elastic' => $txt['fancybox_close_set_unu'], 'fade' => $txt['fancybox_close_set_du'], 'none' => $txt['no'])),
		array('int', 'fancybox_close_speed'),
		array('select', 'fancybox_next_effect', array('elastic' => $txt['fancybox_effect_unu'], 'fade' => $txt['fancybox_effect_du'], 'none' => $txt['no'])),
		array('int', 'fancybox_next_speed'),
		array('select', 'fancybox_prev_effect', array('elastic' => $txt['fancybox_effect_unu'], 'fade' => $txt['fancybox_effect_du'], 'none' => $txt['no'])),
		array('int', 'fancybox_prev_speed'),
		array('select', 'fancybox_title_position', array('float' => $txt['fancybox_title_set_unu'], 'inside' => $txt['fancybox_title_set_du'], 'outside' => $txt['fancybox_title_set_tri'], 'over' => $txt['fancybox_title_set_kvar'])),
		array('check', 'fancybox_autoplay'),
		array('int', 'fancybox_playspeed'),
		array('check', 'fancybox_thumbnails'),
		array('select', 'fancybox_panel_position', 'disabled' => !empty($modSettings['fancybox_thumbnails']) ? 'disabled' : '', array('top' => $txt['fancybox_panel_set_unu'], 'bottom' => $txt['fancybox_panel_set_du'])),
		array('check', 'fancybox_prepare'),
		array('check', 'fancybox_traffic', 'disabled' => empty($modSettings['fancybox_prepare']) ? 'disabled' : '')
	);
	
	// Saving?
	if (isset($_GET['save'])) {
		checkSession();
		saveDBSettings($config_vars);
		redirectexit('action=admin;area=modsettings;sa=fancybox');
	}
	
	prepareDBSettingContext($config_vars);
}

?>