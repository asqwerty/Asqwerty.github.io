[center][img]http://linkme.ufanet.ru/images/c7329379e5d324fa3e8158304814187b.jpg[/img] [img]http://linkme.ufanet.ru/images/c7329379e5d324fa3e8158304814187b.jpg[/img] [img]http://linkme.ufanet.ru/images/c7329379e5d324fa3e8158304814187b.jpg[/img][hr][color=red][size=16pt][b]Scrolling Buttons[/b][/size][/color]
[color=blue][b][size=10pt]Yoda[/size][/b][/color]

[color=green]Go Up/Go Down buttons for screen scrolling, with jQuery.[/color]
Powered by MaxSite CMS's [url=http://skeet.gq/]plugin[/url].[/center][hr]Yoda [url=http://skeet.gq/]CC BY-NC-SA[/url]